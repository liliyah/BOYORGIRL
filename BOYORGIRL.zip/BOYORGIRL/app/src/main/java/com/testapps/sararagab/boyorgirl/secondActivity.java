package com.testapps.sararagab.boyorgirl;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.Toast;

public class secondActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private  Toolbar toolbar;
 private DrawerLayout drawerLayout;
 private NavigationView navigationView;
 private ovulationfragment movulationfragment;
    private chineseboygirlfragment mchineseboygirlfragment;
    private dietfargment mdietfargment;
    private genderfragment mgenderfragment;
    private pregnancyfragment mpregnancyfragment;
    private  pregnencysyndromefragment mpregnencysyndromefragment;


 private FrameLayout frameLayout;
    private  String genderType;

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(savedInstanceState==null){
            mpregnancyfragment = new pregnancyfragment();
            getSupportFragmentManager().beginTransaction().add(R.id.fragmentcontainer,mpregnancyfragment).commit();
        }

        setContentView(R.layout.activity_second);
        toolbar = findViewById(R.id.toolbar);
      setSupportActionBar(toolbar);
      drawerLayout = findViewById(R.id.DrawerLayout);
      navigationView = findViewById(R.id.nav_drawer);
      frameLayout = findViewById(R.id.fragmentcontainer);

        Intent intent = getIntent();
         genderType = intent.getStringExtra("genderType");

            frameLayout.setBackground(getApplicationContext().getResources().getDrawable(R.drawable.babybkue));

        Bundle bundle = new Bundle();
        bundle.putString("gender",genderType);



      navigationView.setNavigationItemSelectedListener(this);
        ActionBarDrawerToggle toggle= new ActionBarDrawerToggle(this,drawerLayout,toolbar,
                R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("key","Welcome Back");
        super.onSaveInstanceState(outState);       //save state
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Bundle bundle = new Bundle();
        bundle.putString("gender",genderType);
        switch (menuItem.getItemId()){

            case (R.id.ovulation):
                movulationfragment = new ovulationfragment();

                movulationfragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,movulationfragment).commit();
                  break;
            case (R.id.pregnancy):

                mpregnancyfragment = new pregnancyfragment();
                mpregnancyfragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,mpregnancyfragment).commit();
                break;
            case (R.id.gender):

                mgenderfragment = new genderfragment();
                mgenderfragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,mgenderfragment).commit();
                break;
            case (R.id.diet_icon):

                mdietfargment = new dietfargment();
                mdietfargment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,mdietfargment).commit();
                break;

            case (R.id.chinesegender):

                mchineseboygirlfragment = new chineseboygirlfragment();
                mchineseboygirlfragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,mchineseboygirlfragment).commit();
                break;
            case (R.id.syndrome_icon):

                mpregnencysyndromefragment = new pregnencysyndromefragment();
                mpregnencysyndromefragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,mpregnencysyndromefragment).commit();
                break;
            case (R.id.share):

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "اكنب شيئا .......");
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
                break;


        }

        return true;
    }
}
