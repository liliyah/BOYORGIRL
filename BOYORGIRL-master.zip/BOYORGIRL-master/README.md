# BOYORGIRL
app to help you conceive your favorite  gender . the App is In the Arabic language 
![1](https://user-images.githubusercontent.com/41235606/94475011-c67e7880-01ce-11eb-804c-7d80a7bc5193.jpg)
![4](https://user-images.githubusercontent.com/41235606/94475085-df872980-01ce-11eb-9783-7a9d728f5b1a.jpg)
![2](https://user-images.githubusercontent.com/41235606/94475134-f168cc80-01ce-11eb-8bbe-cd600cc653f2.jpg)
![3](https://user-images.githubusercontent.com/41235606/94475194-05143300-01cf-11eb-88f5-5b0c8d7ab00a.jpg)

